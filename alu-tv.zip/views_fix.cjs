const fs = require('fs');

let html = fs.readFileSync('index.html', 'utf8');

// 1. Update openArticle to hide home-bottom-content
// and increment views
const openArticleRegex = /function openArticle\(id\) \{([\s\S]*?)const formattedDate = formatNewsDate\(article\.id\);/;

const newOpenArticleStart = `function openArticle(id) {
  let article = articles.find(a => a.id == id);
  
  if (!article) {
     article = originals.find(a => a.id == id);
  }
  
  if (!article) return;
  
  if (window.location.hash !== '#post-' + id) {
    history.pushState(null, null, '#post-' + id);
  }
  document.getElementById('homepage-grid').classList.add('hidden');
  const bottomContainer = document.getElementById('home-bottom-content');
  if (bottomContainer) bottomContainer.classList.add('hidden');
  
  const articleView = document.getElementById('single-article-view');
  articleView.classList.remove('hidden');
  
  // Increment views
  if (!article.views) {
      article.views = (Number(article.id) % 50) + 120;
  }
  article.views += 1;
  
  // Try to update firebase
  if (typeof db !== 'undefined' && db) {
     if (article.type === 'original') {
         db.ref('originals/' + article.id).update({ views: article.views }).catch(e => console.log(e));
     } else {
         db.ref('articles/' + article.id).update({ views: article.views }).catch(e => console.log(e));
     }
  }
  
  const formattedDate = formatNewsDate(article.id);`;

html = html.replace(openArticleRegex, newOpenArticleStart);


// 2. Add views to article header in openArticle
// In the 'original' or video view:
// <span class="hidden md:inline">&bull;</span>
// <span>\${formattedDate}</span>
// Add views after formattedDate
html = html.replace(
  /<span>\$\{formattedDate\}<\/span>\s*<\/div>/,
  `<span>\${formattedDate}</span>
            <span class="hidden md:inline">&bull;</span>
            <span class="flex items-center gap-1"><svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path></svg>\${article.views} Views</span>
          </div>`
);

// In the standard article view:
// <span>\${formattedDate}</span>
// <span class="hidden md:inline">&bull;</span>
// <span>By Alu Tv News Desk</span>
html = html.replace(
  /<span>\$\{formattedDate\}<\/span>\s*<span class="hidden md:inline">&bull;<\/span>\s*<span>By Alu Tv News Desk<\/span>\s*<\/div>/,
  `<span>\${formattedDate}</span>
            <span class="hidden md:inline">&bull;</span>
            <span>By Alu Tv News Desk</span>
            <span class="hidden md:inline">&bull;</span>
            <span class="flex items-center gap-1"><svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path></svg>\${article.views} Views</span>
          </div>`
);


// 3. Fix navigate to remove hidden from home-bottom-content
// Inside function navigate(category, event) {
// // Show homepage grid, hide single article
// document.getElementById('homepage-grid').classList.remove('hidden');
// document.getElementById('single-article-view').classList.add('hidden');
const navigateRegex = /document\.getElementById\('homepage-grid'\)\.classList\.remove\('hidden'\);\s*document\.getElementById\('single-article-view'\)\.classList\.add\('hidden'\);/;
html = html.replace(navigateRegex, `document.getElementById('homepage-grid').classList.remove('hidden');
const bottomContainerNav = document.getElementById('home-bottom-content');
if (bottomContainerNav) bottomContainerNav.classList.remove('hidden');
document.getElementById('single-article-view').classList.add('hidden');`);


// 4. Update renderNewsItem for views
const renderNewsItemRegex = /function renderNewsItem\(article\) \{([\s\S]*?)<\/article>\`;/;
const newRenderNewsItem = `function renderNewsItem(article) {
  if (!article.views) article.views = (Number(article.id) % 50) + 120;
  const artDate = formatNewsDate(article.id);
  const img = article.image ? \`<img loading="lazy" src="\${article.image}" alt="\${article.title}" class="w-[100px] h-[75px] object-cover rounded-sm group-hover:opacity-90 transition-opacity flex-shrink-0" />\` : \`<div class="w-[100px] h-[75px] bg-gray-200 rounded-sm flex-shrink-0"></div>\`;
  return \`<article onclick="openArticle('\${article.id}')" class="flex items-center gap-4 border-b border-gray-200 py-4 cursor-pointer group last:border-0">
    \${img}
    <div class="flex flex-col justify-center flex-1">
       <span class="text-[10px] text-news-purple font-bold uppercase tracking-widest mb-1">\${article.category || 'News'}</span>
       <h3 class="font-bold text-base leading-tight mb-1 group-hover:text-purple-700 transition-colors line-clamp-2 text-gray-900">\${article.title}</h3>
       <div class="flex items-center gap-3 text-[11px] text-gray-500 font-medium">
         <span>\${artDate}</span>
         <span class="flex items-center gap-1"><svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path></svg>\${article.views}</span>
       </div>
    </div>
  </article>\`;`;
html = html.replace(renderNewsItemRegex, newRenderNewsItem);


fs.writeFileSync('index.html', html);
