const fs = require('fs');

let html = fs.readFileSync('index.html', 'utf8');

// 1. Fix renderOriginals
const renderOriginalsRegex = /function renderOriginals\(\) \{[\s\S]*?\}\)\.join\(''\);\s*\}/;

const newRenderOriginals = `function renderOriginals() {
    const grid = document.getElementById('documentaryGrid');
    if (!grid) return;
    
    if (originals.length === 0) {
       return;
    }
    
    grid.innerHTML = originals.map(orig => {
       const dateStr = new Date(orig.id).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
       const poster = orig.posterUrl || 'documentary-cover.jpg';
       const embedUrl = getYouTubeEmbedUrl(orig.videoUrl);
       
       let playerHtml = '';
       if (embedUrl !== orig.videoUrl) {
           playerHtml = \`<iframe loading="lazy" width="100%" height="315" src="\${embedUrl}" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen class="w-full aspect-video border-0"></iframe>\`;
       } else {
           playerHtml = \`
              <video controls preload="metadata" poster="\${poster}" class="w-full aspect-video object-cover bg-black block">
                <source src="\${orig.videoUrl}" type="video/mp4">
                Your browser does not support the video tag.
              </video>
           \`;
       }
       return \`
          <div class="cinematic-card" onclick="openArticle('\${orig.id}')" style="cursor:pointer;">
            <div class="video-container">
              \${playerHtml}
            </div>
            <div class="cinematic-meta">
              <span class="badge">\${orig.badge || 'ORIGINAL'}</span>
              <h3>\${orig.title}</h3>
              <p class="pub-date">Published: \${dateStr}</p>
            </div>
          </div>
       \`;
    }).join('');
}`;

if (html.match(renderOriginalsRegex)) {
    html = html.replace(renderOriginalsRegex, newRenderOriginals);
}

// 2. Fix openArticle
const openArticleRegex = /function openArticle\(id\) \{[\s\S]*?window\.scrollTo\(\{ top: 0, behavior: 'smooth' \}\);\s*\}/;

const newOpenArticle = `function openArticle(id) {
  let article = articles.find(a => a.id == id);
  
  if (!article) {
     article = originals.find(a => a.id == id);
  }
  
  if (!article) return;
  
  if (window.location.hash !== '#post-' + id) {
    history.pushState(null, null, '#post-' + id);
  }
  document.getElementById('homepage-grid').classList.add('hidden');
  const articleView = document.getElementById('single-article-view');
  articleView.classList.remove('hidden');
  
  const formattedDate = formatNewsDate(article.id);
  
  let layoutHTML = '';

  if (article.type === 'video' || article.type === 'original') {
      // STRICT VIDEO VIEW
      const ytUrl = getYouTubeEmbedUrl(article.videoUrl);
      let playerHtml = '';
      if (ytUrl !== article.videoUrl) {
          playerHtml = \`<div class="mb-8 w-full">
             <iframe loading="lazy" width="100%" height="450" src="\${ytUrl}" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
          </div>\`;
      } else {
          playerHtml = \`<div class="custom-video-wrapper w-full mb-8 bg-black rounded-lg overflow-hidden border-2 border-news-purple shadow-[0_0_15px_rgba(59,7,100,0.5)] aspect-video">
            <video controls preload="metadata" poster="\${article.image || article.posterUrl || 'placeholder.jpg'}" style="width:100%; height:100%; object-fit:cover; border-radius:8px; background:#000;">
              <source src="\${article.videoUrl}" type="video/mp4">
              Your browser does not support the video tag.
            </video>
          </div>\`;
      }
      
      layoutHTML = \`
        <article class="bg-white p-4 md:p-8 shadow-sm rounded-lg border border-gray-200 flex-1 w-full">
          <button onclick="navigate('Home', event)" class="text-news-purple hover:text-news-purple flex items-center gap-2 text-sm font-bold uppercase tracking-wider mb-6 transition-colors">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
            Back
          </button>
          
          <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
            <h1 class="text-3xl md:text-4xl font-black text-gray-900 leading-tight tracking-tighter flex-1">\${article.title}</h1>
            <button onclick="shareArticle('\${article.title.replace(/'/g, "\\\\'")}', '')" class="bg-news-purple text-white px-4 py-2 rounded text-sm font-bold flex items-center justify-center gap-2 hover:bg-purple-800 transition-colors shrink-0">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z"></path></svg>Share
            </button>
          </div>
          
          <div class="flex flex-wrap items-center gap-2 md:gap-3 text-xs md:text-sm text-gray-500 font-bold uppercase tracking-wide mb-6">
            <span class="bg-news-purple text-white px-2 py-1 rounded-sm">\${article.category || article.badge || 'VIDEO'}</span>
            <span class="hidden md:inline">&bull;</span>
            <span>\${formattedDate}</span>
          </div>
          
          \${playerHtml}
        </article>
      \`;

  } else {
      // STANDARD NEWS ARTICLE
      let topMediaHTML = '';
      if (article.image) {
          topMediaHTML = \`<div class="w-full mb-8"><img loading="lazy" src="\${article.image}" alt="\${article.title}" class="w-full h-auto max-h-[500px] object-cover rounded-lg shadow-sm" /></div>\`;
      }
      
      let text = article.content || '<p>Content missing.</p>';
      text = text.replace(/\\[(?:see-also|related):\\s*([^\\]]+)\\]/g, (match, targetTitle) => {
         const cleanTargetTitle = targetTitle.trim().toLowerCase();
         const relatedNews = articles.find(item =>
             item.title && item.title.trim().toLowerCase() === cleanTargetTitle
         );
         if (relatedNews) {
            return \`<div class="see-also-container" style="margin: 20px 0; padding: 12px; background: #f9f9f9; border-left: 4px solid #7b1fa2; border-radius: 4px;">
               <span style="font-size: 11px; font-weight: bold; color: #7b1fa2; text-transform: uppercase; display: block; margin-bottom: 4px;">See Also:</span>
               <a href="#post-\${relatedNews.id}" class="see-also-link" style="color: #111; font-weight: bold; text-decoration: none; font-size: 15px; display: inline-block;" onclick="openArticle('\${relatedNews.id}'); return false;">
                  \${relatedNews.title} ➔
               </a>
            </div>\`;
         }
         return '';
      });

      if (article.bodyImage) {
         const midpoint = Math.floor(text.length / 2);
         const brk = text.indexOf('</p>', midpoint);
         if (brk !== -1) {
           text = text.substring(0, brk + 4) + \`<div class="w-full my-6"><img loading="lazy" src="\${article.bodyImage}" class="w-full h-auto object-cover rounded-lg shadow-sm" /></div>\` + text.substring(brk + 4);
         } else {
           text += \`<div class="w-full my-6"><img loading="lazy" src="\${article.bodyImage}" class="w-full h-auto object-cover rounded-lg shadow-sm" /></div>\`;
         }
      }
      
      let audioHtml = '';
      if (article.type === 'audio' && article.audioUrl) {
          audioHtml = \`<div class="custom-audio-container w-full mb-8 bg-[#f5f5f5] p-4 rounded-lg border-l-[4px] border-news-purple shadow-sm">
          <p class="text-gray-900 font-bold mb-2 text-[13px]">🎵 Saurari Labari (Audio):</p>
          <audio controls class="w-full h-[40px] mb-2">
            <source src="\${article.audioUrl}" type="audio/mpeg">
            Your browser does not support the audio element.
          </audio>
          <div class="text-right mt-2">
            <a href="\${article.audioUrl}" download="AluTv-\${article.title.replace(/\\s+/g, '-').toLowerCase()}.mp3" target="_blank" class="bg-news-purple text-white px-3 py-1.5 no-underline rounded text-xs inline-block font-bold hover:bg-purple-800 transition-colors">
              📥 Saukar da Audio (Direct Download)
            </a>
          </div>
        </div>\`;
      }
      
      let contentHTML = \`
        <div class="text-base md:text-lg text-gray-800 leading-relaxed space-y-6">
          <p class="font-bold text-lg md:text-xl text-gray-900 border-l-4 border-news-purple pl-4 py-1">\${article.subtitle || article.summary || ''}</p>
          <div class="rich-content space-y-4 pt-4">\${text}</div>
        </div>
      \`;
      
      layoutHTML = \`
        <article class="bg-white p-4 md:p-8 shadow-sm rounded-lg border border-gray-200 flex-1 w-full">
          <button onclick="navigate('Home', event)" class="text-news-purple hover:text-news-purple flex items-center gap-2 text-sm font-bold uppercase tracking-wider mb-6 transition-colors">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
            Back
          </button>
          
          <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
            <h1 class="text-3xl md:text-4xl font-black text-gray-900 leading-tight tracking-tighter flex-1">\${article.title}</h1>
            <button onclick="shareArticle('\${article.title.replace(/'/g, "\\\\'")}', '\${(article.summary || '').replace(/'/g, "\\\\'")}')" class="bg-news-purple text-white px-4 py-2 rounded text-sm font-bold flex items-center justify-center gap-2 hover:bg-purple-800 transition-colors shrink-0">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z"></path></svg>Share
            </button>
          </div>
          
          <div class="flex flex-wrap items-center gap-2 md:gap-3 text-xs md:text-sm text-gray-500 font-bold uppercase tracking-wide mb-6">
            <span class="bg-news-purple text-white px-2 py-1 rounded-sm">\${article.category || 'News'}</span>
            <span class="hidden md:inline">&bull;</span>
            <span>\${formattedDate}</span>
            <span class="hidden md:inline">&bull;</span>
            <span>By Alu Tv News Desk</span>
          </div>
          
          \${topMediaHTML}
          \${audioHtml}
          \${contentHTML}
        </article>
      \`;
  }
  
  articleView.innerHTML = layoutHTML;
  window.scrollTo({ top: 0, behavior: 'smooth' });
}`;

if (html.match(openArticleRegex)) {
    html = html.replace(openArticleRegex, newOpenArticle);
}

fs.writeFileSync('index.html', html);
