const fs = require('fs');
let html = fs.readFileSync('index.html', 'utf8');

const oldSubMap = /htmlContent \+= sub\.map\(article => \{[\s\S]*?\}\)\.join\(''\);/;
html = html.replace(oldSubMap, `htmlContent += sub.map(renderNewsItem).join('');`);


// Fix feature article view count
const featureArticleRegex = /const featureMedia = feature\.image \? [\s\S]*?<\/article>\`;/;
html = html.replace(featureArticleRegex, (match) => {
    return match.replace(
        /<span class="text-gray-500 text-\[11px\] font-bold uppercase tracking-wider">\$\{featureDate\}<\/span>/,
        `<div class="flex items-center gap-3 text-gray-500 text-[11px] font-bold uppercase tracking-wider">
           <span>\${featureDate}</span>
           <span class="flex items-center gap-1"><svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path></svg>\${feature.views || ((Number(feature.id) % 50) + 120)} Views</span>
         </div>`
    );
});


// Fix video articles map
const videoArticlesMapRegex = /vidContent \+= videoArticles\.map\(article => \{[\s\S]*?\}\)\.join\(''\);/;
html = html.replace(videoArticlesMapRegex, (match) => {
    return match.replace(
        /<p class="text-gray-300 text-xs mt-2 font-medium">\$\{artDate\}<\/p>/,
        `<div class="flex items-center gap-3 text-gray-300 text-xs mt-2 font-medium">
            <span>\${artDate}</span>
            <span class="flex items-center gap-1"><svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path></svg>\${article.views || ((Number(article.id) % 50) + 120)} Views</span>
         </div>`
    );
});


// Fix renderOriginals map
const renderOriginalsRegex = /grid\.innerHTML = originals\.map\(orig => \{[\s\S]*?\}\)\.join\(''\);/;
html = html.replace(renderOriginalsRegex, (match) => {
    return match.replace(
        /<p class="pub-date">Published: \$\{dateStr\}<\/p>/,
        `<div class="flex items-center gap-3 text-gray-300 text-xs mt-2 font-medium">
             <span>Published: \${dateStr}</span>
             <span class="flex items-center gap-1"><svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path></svg>\${orig.views || ((Number(orig.id) % 50) + 120)} Views</span>
         </div>`
    );
});


// Fix live search map outputContainer
const searchRegex = /filteredArticles\.forEach\(article => \{[\s\S]*?\}\);/;
// Actually search uses renderNewsItem, so it's already covered!
const searchCheck = /filteredArticles\.forEach\(article => \{\s*outputContainer\.innerHTML \+= renderNewsItem\(article\);\s*\}\);/;


fs.writeFileSync('index.html', html);
