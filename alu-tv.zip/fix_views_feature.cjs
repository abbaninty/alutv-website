const fs = require('fs');
let html = fs.readFileSync('index.html', 'utf8');

html = html.replace(
    /<span class="text-\[11px\] text-gray-500 font-medium block mt-2">\$\{featureDate\}<\/span>/,
    `<div class="flex items-center gap-3 text-gray-500 text-[11px] font-medium block mt-2">
       <span>\${featureDate}</span>
       <span class="flex items-center gap-1"><svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path></svg>\${feature.views || ((Number(feature.id) % 50) + 120)} Views</span>
     </div>`
);

fs.writeFileSync('index.html', html);
