const fs = require('fs');
let html = fs.readFileSync('index.html', 'utf8');

const targetStr = `let text = article.content || '<p>Content missing.</p>';`;

if (html.includes(targetStr)) {
    const newLogic = `
    let text = article.content || '<p>Content missing.</p>';
    
    // Parse related post shortcodes: [related:DOCUMENT_ID]
    text = text.replace(/\\[related:([a-zA-Z0-9_\\-]+)\\]/g, (match, relId) => {
       const relArticle = articles.find(a => a.id === relId);
       if (relArticle) {
          return \`<div class="w-full bg-gray-100 border-l-[5px] border-news-purple p-4 my-6 shadow-sm">
             <span class="font-bold text-gray-900">See also: </span>
             <a href="#post-\${relId}" class="text-news-purple hover:underline font-bold" onclick="openArticle('\${relId}'); return false;">\${relArticle.title}</a>
          </div>\`;
       }
       return ''; // Remove if not found
    });
`;
    
    html = html.replace(targetStr, newLogic);
    fs.writeFileSync('index.html', html);
    console.log('Update successful');
} else {
    console.log('Error: Could not find target string');
}
