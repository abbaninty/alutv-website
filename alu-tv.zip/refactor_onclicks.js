const fs = require('fs');
let html = fs.readFileSync('index.html', 'utf8');

// Replace all onclick="openArticle('ID')" with class and data-id
html = html.replace(/onclick="openArticle\('([^']+)'\)"/g, 'class="js-open-article" data-id="$1"');
// Note: some have class already. If we replace it like above, we might end up with `class="js-open-article" data-id="123" class="flex ..."` which is invalid HTML (two class attributes).
// It's better to inject it into the existing class attribute or just leave it as an inline event listener.

fs.writeFileSync('index.html.tmp', html);
