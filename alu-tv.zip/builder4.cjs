const fs = require('fs');
let html = fs.readFileSync('index.html', 'utf8');

// Update openArticle
html = html.replace(
  '<div class="w-full mb-8">\n<img src="${article.image}" alt="${article.title}" class="w-full h-auto max-h-[500px] object-cover rounded-lg shadow-sm" />\n</div>',
  `${"$"}{article.videoUrl ? \`
<div class="w-full mb-8 bg-black rounded-lg overflow-hidden">
<video controls playsinline class="w-full h-auto max-h-[500px] object-contain" poster="\${article.image}">
<source src="\${article.videoUrl}" type="video/mp4">
Your browser does not support HTML video.
</video>
</div>\` : \`
<div class="w-full mb-8">
<img src="\${article.image}" alt="\${article.title}" class="w-full h-auto max-h-[500px] object-cover rounded-lg shadow-sm" />
</div>\`}

${"$"}{article.audioUrl ? \`
<div class="w-full mb-8 bg-news-purple/10 p-4 md:p-6 rounded-lg border border-news-purple/20">
<h4 class="text-news-purple font-black text-sm uppercase tracking-widest mb-3 flex items-center gap-2">
<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z"></path></svg>
Saurari Labarin
</h4>
<audio controls class="w-full">
<source src="\${article.audioUrl}" type="audio/mpeg">
Your browser does not support the audio element.
</audio>
</div>\` : ''}`
);


// Update featureArticle in renderArticles
html = html.replace(
  '<img src="${feature.image}" alt="${feature.title}" class="absolute inset-0 w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform duration-700"/>',
  `${"$"}{feature.videoUrl ? \`
<video controls playsinline class="absolute inset-0 w-full h-full object-cover z-20" poster="\${feature.image}">
<source src="\${feature.videoUrl}" type="video/mp4">
</video>
\` : \`
<img src="\${feature.image}" alt="\${feature.title}" class="absolute inset-0 w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform duration-700"/>
\`}
${"$"}{feature.audioUrl ? \`
<div class="absolute top-4 right-4 z-30 pointer-events-auto w-64">
<audio controls class="w-full h-8 shadow-lg rounded-full" style="filter: drop-shadow(0 4px 6px rgba(0,0,0,0.5));">
<source src="\${feature.audioUrl}" type="audio/mpeg">
</audio>
</div>\` : ''}`
);

// Update subArticles in renderArticles
html = html.replace(
  '<img src="${article.image}" alt="${article.title}" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"/>',
  `${"$"}{article.videoUrl ? \`
<video class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" poster="\${article.image}" preload="metadata">
<source src="\${article.videoUrl}#t=0.1" type="video/mp4">
</video>
<div class="absolute bottom-1 right-1 bg-black/70 text-white rounded p-1">
<svg class="w-3 h-3" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
</div>
\` : \`
<img src="\${article.image}" alt="\${article.title}" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"/>
\`}
${"$"}{article.audioUrl ? \`
<div class="absolute top-1 left-1 bg-news-purple text-white rounded p-1 shadow-sm">
<svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3"></path></svg>
</div>\` : ''}`
);

fs.writeFileSync('index.html', html);
console.log('Done replacement part 4');
