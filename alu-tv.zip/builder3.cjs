const fs = require('fs');
let html = fs.readFileSync('index.html', 'utf8');

// Remove old handleVideoUpdate, handleAudioUpdate, deleteAudioItem, renderAudioPlaylist, loadAudioIndex, toggleAudio
const functionsToRemove = [
  /function handleVideoUpdate\(e\) \{[\s\S]*?\}\s*\}\s*\}/,
  /function deleteAudioItem\(id\) \{[\s\S]*?\}/,
  /function handleAudioUpdate\(e\) \{[\s\S]*?\}\s*\}\s*\}/,
  /function renderAudioPlaylist\(\) \{[\s\S]*?\}\s*\}\s*\}/,
  /function loadAudioIndex\(index, playNow\) \{[\s\S]*?\}\s*\}\s*\}/,
  /function toggleAudio\(\) \{[\s\S]*?\}\s*\}/,
  /window\.playAudioFromPlaylist = function\(index\) \{[\s\S]*?\};/,
  /db\.ref\('settings\/videoUrl'\)\.on\('value', \(snapshot\) => \{[\s\S]*?\}\);/,
  /let audioPlaylist = \[\];[\s\S]*?db\.ref\('audioPlaylist'\)\.on\('value', \(snapshot\) => \{[\s\S]*?\}\);/,
  /function getResponsiveVideoPlayer\(url\) \{[\s\S]*?\}\s*\}/,
  /const audio = document\.getElementById\('audio-player'\);[\s\S]*?\}\);/ // this matches the audio event listeners and consts
];

for (const regex of functionsToRemove) {
  html = html.replace(regex, '');
}

// Ensure the audio constants and listeners are fully removed
html = html.replace(/const audio = document\.getElementById\('audio-player'\);\s*const playIcon = document\.getElementById\('audio-icon-play'\);\s*const pauseIcon = document\.getElementById\('audio-icon-pause'\);\s*const progressBar = document\.getElementById\('audio-progress'\);\s*const statusText = document\.getElementById\('audio-player-status'\);/, '');
html = html.replace(/audio\.addEventListener\('timeupdate', \(\) => \{[\s\S]*?\}\);/, '');
html = html.replace(/audio\.addEventListener\('ended', \(\) => \{[\s\S]*?\}\);/, '');


// Update resetArticleForm
html = html.replace(
  "document.getElementById('admin-art-image').setAttribute('required', 'required');",
  "document.getElementById('admin-art-image').setAttribute('required', 'required');\ndocument.getElementById('admin-art-video-url').value = '';\ndocument.getElementById('admin-art-audio-url').value = '';"
);

// Update editPost
html = html.replace(
  "document.getElementById('admin-art-content').innerHTML = article.content || '';",
  "document.getElementById('admin-art-content').innerHTML = article.content || '';\ndocument.getElementById('admin-art-video-url').value = article.videoUrl || '';\ndocument.getElementById('admin-art-audio-url').value = article.audioUrl || '';"
);

// Update handleArticleSubmit
html = html.replace(
  "const status = document.getElementById('admin-art-status').value;\nconst content = document.getElementById('admin-art-content').innerHTML;",
  "const status = document.getElementById('admin-art-status').value;\nconst content = document.getElementById('admin-art-content').innerHTML;\nconst videoUrl = document.getElementById('admin-art-video-url').value;\nconst audioUrl = document.getElementById('admin-art-audio-url').value;"
);
html = html.replace(
  "saveArticleData(id, title, category, status, content, summary, image);",
  "saveArticleData(id, title, category, status, content, summary, image, videoUrl, audioUrl);"
);
html = html.replace(
  "saveArticleData(id, title, category, status, content, summary, existingArticle.image);",
  "saveArticleData(id, title, category, status, content, summary, existingArticle.image, videoUrl, audioUrl);"
);

// Update saveArticleData
html = html.replace(
  "function saveArticleData(id, title, category, status, content, summary, image) {",
  "function saveArticleData(id, title, category, status, content, summary, image, videoUrl, audioUrl) {"
);
html = html.replace(
  "{ title, category, status, content, summary, image }",
  "{ title, category, status, content, summary, image, videoUrl, audioUrl }"
);
html = html.replace(
  "{ id: newId, title, category, status, content, summary, image }",
  "{ id: newId, title, category, status, content, summary, image, videoUrl, audioUrl }"
);

fs.writeFileSync('index.html', html);
console.log('Done replacement part 3');
