const fs = require('fs');
let html = fs.readFileSync('index.html', 'utf8');

// The remaining broken ones:
// <div class="cinematic-card" class="js-open-article" data-article-id="${orig.id}" style="cursor:pointer;">
html = html.replace(/class="([^"]+)" class="js-open-article([^"]*)" data-article-id="([^"]+)"/g, 'class="$1 js-open-article$2" data-article-id="$3"');

// <div class="p-4 cursor-pointer flex-1" class="js-open-article" data-article-id="${article.id}">
// <div class="cursor-pointer" class="js-open-article" data-article-id="${article.id}">

fs.writeFileSync('index.html', html);
