const fs = require('fs');
let html = fs.readFileSync('index.html', 'utf8');
// Remove HTML comments except some important ones
html = html.replace(/<!--(.*?)-->/gs, '');
// Minify a bit of whitespace but keep newlines for readability
html = html.replace(/^[ \t]+/gm, ''); // remove leading spaces
html = html.replace(/\n\s*\n/g, '\n'); // remove empty lines
fs.writeFileSync('index.html', html);
