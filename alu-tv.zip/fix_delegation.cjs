const fs = require('fs');
let html = fs.readFileSync('index.html', 'utf8');

// Replacements
html = html.replace(/onclick="openArticle\('([^']+)'\)"/g, 'class="js-open-article" data-article-id="$1"');

// Wait, the 1073: <a href="..." class="see-also-link" ... onclick="openArticle('${relatedNews.id}'); return false;">
html = html.replace(/onclick="openArticle\('([^']+)'\); return false;"/g, 'class="js-open-article see-also-link" data-article-id="$1"');

// Need to make sure the global event listener exists
const listener = `
// GLOBAL EVENT DELEGATION
document.addEventListener('click', function(e) {
    const articleLink = e.target.closest('.js-open-article');
    if (articleLink) {
        e.preventDefault();
        const articleId = articleLink.getAttribute('data-article-id');
        if (articleId) {
            openArticle(articleId);
        }
    }
});
`;

if (!html.includes('GLOBAL EVENT DELEGATION')) {
    html = html.replace('document.addEventListener(\'DOMContentLoaded\', () => {', 'document.addEventListener(\'DOMContentLoaded\', () => {' + listener);
}

fs.writeFileSync('index.html', html);
