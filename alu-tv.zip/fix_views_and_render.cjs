const fs = require('fs');
let html = fs.readFileSync('index.html', 'utf8');

// Fix views NaN bug
html = html.replace(/if \(\!article\.views\) \{\s*article\.views = \(Number\(article\.id\) \% 50\) \+ 120;\s*\}/g, 
`if (!article.views) {
      let numericId = Number(article.id);
      article.views = isNaN(numericId) ? Math.floor(Math.random() * 50) + 120 : (numericId % 50) + 120;
  }`);

// Also fix in renderNewsItem
html = html.replace(/if \(\!article\.views\) article\.views = \(Number\(article\.id\) \% 50\) \+ 120;/g,
`if (!article.views) { let numericId = Number(article.id); article.views = isNaN(numericId) ? Math.floor(Math.random() * 50) + 120 : (numericId % 50) + 120; }`);

// Fix renderArticles unhiding bottomContainer
const renderArticlesBottomRegex = /if\(bottomContainer\) \{\s*bottomContainer\.innerHTML = bottomContent;\s*if\(bottomContent\.trim\(\) !== ''\) \{\s*bottomContainer\.classList\.remove\('hidden'\);\s*\} else \{\s*bottomContainer\.classList\.add\('hidden'\);\s*\}\s*\}/;

const newRenderArticlesBottom = `if(bottomContainer) {
    bottomContainer.innerHTML = bottomContent;
    const singleArticleView = document.getElementById('single-article-view');
    const isArticleOpen = singleArticleView && !singleArticleView.classList.contains('hidden');
    if (!isArticleOpen) {
        if(bottomContent.trim() !== '') {
           bottomContainer.classList.remove('hidden');
        } else {
           bottomContainer.classList.add('hidden');
        }
    }
  }`;

html = html.replace(renderArticlesBottomRegex, newRenderArticlesBottom);

fs.writeFileSync('index.html', html);
