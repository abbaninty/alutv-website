const fs = require('fs');
let html = fs.readFileSync('index.html', 'utf8');

// Minify html
html = html.replace(/\s+/g, ' ').trim();
// Remove space between tags
html = html.replace(/>\s+</g, '><');

fs.writeFileSync('index.min.html', html);
