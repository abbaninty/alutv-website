const fs = require('fs');

let html = fs.readFileSync('index.html', 'utf8');

const regexOpen = /playerHtml = \`<div class="mb-8 w-full">\s*<iframe loading="lazy" width="100%" height="450" src="\$\{ytUrl\}" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen><\/iframe>\s*<\/div>\`;/;

html = html.replace(regexOpen, `playerHtml = \\\`<div class="mb-8 w-full aspect-video">
             \\\${createYouTubeLazyPlayer(article.videoUrl, "w-full h-full", "w-full h-full")}
          </div>\\\`;`);

fs.writeFileSync('index.html', html);
