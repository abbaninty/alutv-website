const fs = require('fs');
let html = fs.readFileSync('index.html', 'utf8');

html = html.replace(/class="see-also-link" style="([^"]+)" class="js-open-article see-also-link"/g, 'class="js-open-article see-also-link" style="$1"');

fs.writeFileSync('index.html', html);
