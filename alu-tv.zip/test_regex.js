const url1 = "https://drive.google.com/file/d/1234567890abcdef/view";
const url2 = "https://drive.google.com/uc?id=1234567890abcdef&export=download";
const match1 = url1.match(/(?:[?&]id=|\/d\/)([^/&?]+)/);
console.log(match1 ? match1[1] : "no match");
const match2 = url2.match(/(?:[?&]id=|\/d\/)([^/&?]+)/);
console.log(match2 ? match2[1] : "no match");
