const fs = require('fs');

let html = fs.readFileSync('index.html', 'utf8');

const lazyPlayerScript = `
function getYouTubeVideoId(url) {
    if (!url) return '';
    if (/^[a-zA-Z0-9_-]{11}$/.test(url)) {
        return url;
    }
    const match = url.match(/(?:youtu\\.be\\/|youtube\\.com\\/(?:embed\\/|v\\/|watch\\?v=|watch\\?.+&v=))((\\w|-){11})/);
    return match ? match[1] : '';
}

function createYouTubeLazyPlayer(url, containerClasses, iframeClasses) {
    const videoId = getYouTubeVideoId(url);
    if (!videoId) return '';
    
    const thumbUrl = 'https://img.youtube.com/vi/' + videoId + '/hqdefault.jpg';
    
    return \`
      <div class="youtube-lazy-player \${containerClasses}" data-videoid="\${videoId}" data-iframeclasses="\${iframeClasses}" style="position:relative; cursor:pointer; background-image:url('\${thumbUrl}'); background-size:cover; background-position:center; display:flex; align-items:center; justify-content:center;" onclick="loadYouTubeIframe(this, event)">
        <div style="width:68px; height:48px; display:flex; align-items:center; justify-content:center; transition: opacity 0.3s;" class="hover:opacity-80">
          <svg viewBox="0 0 68 48" width="68" height="48"><path d="M66.52,7.74c-0.78-2.93-2.49-5.41-5.42-6.19C55.79,.13,34,0,34,0S12.21,.13,6.9,1.55 C3.97,2.33,2.27,4.81,1.48,7.74C0.06,13.05,0,24,0,24s0.06,10.95,1.48,16.26c0.78,2.93,2.49,5.41,5.42,6.19 C12.21,47.87,34,48,34,48s21.79-0.13,27.1-1.55c2.93-0.78,4.64-3.26,5.42-6.19C67.94,34.95,68,24,68,24S67.94,13.05,66.52,7.74z" fill="#FF0000"></path><path d="M 45,24 27,14 27,34" fill="#fff"></path></svg>
        </div>
      </div>
    \`;
}

function loadYouTubeIframe(container, event) {
    if(event) {
        event.stopPropagation();
        event.preventDefault();
    }
    const videoId = container.dataset.videoid;
    const classes = container.dataset.iframeclasses || '';
    
    const iframeHtml = \\\`<iframe loading="lazy" class="\\\${classes}" src="https://www.youtube.com/embed/\\\${videoId}?autoplay=1&controls=1&modestbranding=1&rel=0" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen style="width:100%; height:100%; position:absolute; top:0; left:0;"></iframe>\\\`;
    
    container.style.backgroundImage = 'none';
    container.style.cursor = 'default';
    container.onclick = null;
    container.innerHTML = iframeHtml;
}
`;

// Insert the new JS functions just before `function getYouTubeEmbedUrl`
html = html.replace(/function getYouTubeEmbedUrl/, lazyPlayerScript + '\nfunction getYouTubeEmbedUrl');

// 1. renderOriginals
// old:
// let playerHtml = '';
// if (embedUrl !== orig.videoUrl) {
//     playerHtml = `<iframe loading="lazy" width="100%" height="315" src="${embedUrl}" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen class="w-full aspect-video border-0"></iframe>`;
// } else { ... }
// new:
// if (embedUrl !== orig.videoUrl) {
//     playerHtml = createYouTubeLazyPlayer(orig.videoUrl, "w-full aspect-video border-0", "w-full aspect-video border-0");
// }
const renderOriginalsRegex = /let playerHtml = '';\s*if \(embedUrl !== orig\.videoUrl\) \{\s*playerHtml = `<iframe loading="lazy" width="100%" height="315" src="\$\{embedUrl\}" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen class="w-full aspect-video border-0"><\/iframe>`;\s*\} else \{/g;
html = html.replace(renderOriginalsRegex, `let playerHtml = '';
       if (embedUrl !== orig.videoUrl) {
           playerHtml = createYouTubeLazyPlayer(orig.videoUrl, "w-full aspect-video border-0 overflow-hidden", "w-full aspect-video border-0");
       } else {`);


// 2. renderArticles -> SECTION 2: LATEST VIDEOS
const renderVideosRegex = /let playerHtml = '';\s*if \(embedUrl !== article\.videoUrl\) \{\s*playerHtml = `<iframe loading="lazy" width="100%" height="315" src="\$\{embedUrl\}" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen style="position: absolute; top: 0; left: 0; width: 100%; height: 100%;"><\/iframe>`;\s*\} else \{/g;
html = html.replace(renderVideosRegex, `let playerHtml = '';
        if (embedUrl !== article.videoUrl) {
            playerHtml = createYouTubeLazyPlayer(article.videoUrl, "absolute inset-0 w-full h-full", "absolute inset-0 w-full h-full");
        } else {`);

fs.writeFileSync('index.html', html);
