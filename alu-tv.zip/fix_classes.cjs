const fs = require('fs');
let html = fs.readFileSync('index.html', 'utf8');

// Use regex to merge class="js-open-article" data-article-id="123" class="other-classes"
// into class="js-open-article other-classes" data-article-id="123"
html = html.replace(/class="js-open-article([^"]*)" data-article-id="([^"]+)" class="([^"]+)"/g, 'class="js-open-article$1 $3" data-article-id="$2"');

fs.writeFileSync('index.html', html);
