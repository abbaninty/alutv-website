const fs = require('fs');
let html = fs.readFileSync('index.html', 'utf8');

const headContent = `  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Alu Tv</title>
  
  <!-- Open Graph Meta Tags -->
  <meta property="og:title" content="Alu Tv">
  <meta property="og:description" content="Alu Tv - Top News, Politics, Business, Security, and more.">
  <meta property="og:type" content="website">
  <meta property="og:image" content="https://placehold.co/1200x630/3B0764/ffffff.png?text=ALU+TV">
  <meta property="og:url" content="https://alutv.com">
  <meta name="twitter:card" content="summary_large_image">
`;

html = html.replace(/<meta charset="UTF-8">\s*<meta name="viewport" content="width=device-width, initial-scale=1.0">\s*<title>Alu Tv<\/title>/, headContent);

fs.writeFileSync('index.html', html);
