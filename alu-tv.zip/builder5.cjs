const fs = require('fs');
let html = fs.readFileSync('index.html', 'utf8');

html = html.replace(
  '<div class="w-24 h-full bg-gray-200 flex-shrink-0 mr-4 overflow-hidden rounded-sm">',
  '<div class="relative w-24 h-full bg-gray-200 flex-shrink-0 mr-4 overflow-hidden rounded-sm">'
);

fs.writeFileSync('index.html', html);
console.log('Done replacement part 5');
