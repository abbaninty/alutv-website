const fs = require('fs');

let html = fs.readFileSync('index.html', 'utf8');

// 1. Remove firebase scripts from head
html = html.replace(/<script crossorigin="anonymous" src="https:\/\/www\.gstatic\.com\/firebasejs\/[^"]+"><\/script>\n?/g, '');

// 2. Add them back just before the main logic script
const firebaseScripts = `<script crossorigin="anonymous" src="https://www.gstatic.com/firebasejs/10.9.0/firebase-app-compat.js"></script>
<script crossorigin="anonymous" src="https://www.gstatic.com/firebasejs/10.9.0/firebase-database-compat.js"></script>
<script crossorigin="anonymous" src="https://www.gstatic.com/firebasejs/10.9.0/firebase-storage-compat.js"></script>
`;

html = html.replace(/<script>\s*\/\/\ 1\. Firebase Setup & Database Connection/, firebaseScripts + '<script>\n// 1. Firebase Setup & Database Connection');

fs.writeFileSync('index.html', html);
