const fs = require('fs');

let html = fs.readFileSync('index.html', 'utf8');

// 1. YouTube Iframe fix
// In getYouTubeEmbedUrl, let's make it robust
const ytUrlRegexOrig = /function getYouTubeEmbedUrl\(url\)\s*{[\s\S]*?return videoId \? `https:\/\/www\.youtube\.com\/embed\/\${videoId}` : url;\s*}/;
const ytUrlReplacement = `function getYouTubeEmbedUrl(url) {
    if (!url) return '';
    let videoId = '';
    if (/^[a-zA-Z0-9_-]{11}$/.test(url)) {
        videoId = url;
    } else {
        const match = url.match(/(?:youtu\\.be\\/|youtube\\.com\\/(?:embed\\/|v\\/|watch\\?v=|watch\\?.+&v=))((\\w|-){11})/);
        if (match && match[1]) {
            videoId = match[1];
        }
    }
    return videoId ? \`https://www.youtube.com/embed/\${videoId}\` : url;
}`;
html = html.replace(ytUrlRegexOrig, ytUrlReplacement);

// Replace the iframe definitions everywhere.
// The requested iframe format:
// <iframe width="100%" height="315" src="https://www.youtube.com/embed/${videoId}" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
// Note: since embedUrl is already `https://www.youtube.com/embed/${videoId}`, we can just use `\${embedUrl}` or `\${ytUrl}`.

html = html.replace(/<iframe src="\\\${embedUrl}" frameborder="0" allowfullscreen class="w-full aspect-video border-0"><\/iframe>/g, 
'<iframe width="100%" height="315" src="${embedUrl}" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>');

html = html.replace(/<iframe src="\\\${embedUrl}" frameborder="0" allowfullscreen class="absolute inset-0 w-full h-full border-0"><\/iframe>/g, 
'<iframe width="100%" height="315" src="${embedUrl}" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>');

html = html.replace(/<iframe src="\\\${ytUrl}" frameborder="0" allowfullscreen class="absolute top-0 left-0 w-full h-full border-0"><\/iframe>/g, 
'<iframe width="100%" height="315" src="${ytUrl}" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>');

// Remove extra layers (custom-video-wrapper etc) in openArticle if necessary?
// The prompt says "Make sure no extra layers or thumbnail overlay blocks are hiding the iframe player so that the video displays and plays instantly."
// Let's check openArticle in index.html where ytUrl is used.
