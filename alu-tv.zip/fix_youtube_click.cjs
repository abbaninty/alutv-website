const fs = require('fs');
let html = fs.readFileSync('index.html', 'utf8');

// Replace onclick
html = html.replace(/onclick="loadYouTubeIframe\(this, event\)"/g, 'class="js-load-youtube"');

// Wait, the youtube container already has class="youtube-lazy-player ${containerClasses}". Let's inject js-load-youtube into its class list
html = html.replace(/class="youtube-lazy-player ([^"]*)" data-videoid="([^"]+)" data-iframeclasses="([^"]+)" style="([^"]+)" class="js-load-youtube"/g, 'class="youtube-lazy-player js-load-youtube $1" data-videoid="$2" data-iframeclasses="$3" style="$4"');

// Update global listener
const newListener = `
// GLOBAL EVENT DELEGATION
document.addEventListener('click', function(e) {
    const articleLink = e.target.closest('.js-open-article');
    if (articleLink) {
        e.preventDefault();
        const articleId = articleLink.getAttribute('data-article-id');
        if (articleId) {
            openArticle(articleId);
        }
        return;
    }
    
    const youtubeLazy = e.target.closest('.js-load-youtube');
    if (youtubeLazy) {
        e.preventDefault();
        e.stopPropagation();
        loadYouTubeIframe(youtubeLazy);
    }
});
`;

html = html.replace(/\/\/ GLOBAL EVENT DELEGATION[\s\S]*?\n\}\);\n/, newListener);

// Update loadYouTubeIframe signature since it no longer takes an event directly
html = html.replace(/function loadYouTubeIframe\(container, event\) \{/g, 'function loadYouTubeIframe(container) {');
html = html.replace(/if\(event\) \{\s*event\.stopPropagation\(\);\s*event\.preventDefault\(\);\s*\}/g, '');

fs.writeFileSync('index.html', html);
