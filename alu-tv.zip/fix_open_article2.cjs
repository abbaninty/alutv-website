const fs = require('fs');

let html = fs.readFileSync('index.html', 'utf8');

html = html.replace(/playerHtml = \\\`<div class="mb-8 w-full aspect-video">\\s*\\\\\\$\\{createYouTubeLazyPlayer/, 'playerHtml = `<div class="mb-8 w-full aspect-video">\\n             ${createYouTubeLazyPlayer');

fs.writeFileSync('index.html', html);
