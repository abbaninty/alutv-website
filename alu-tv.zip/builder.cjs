const fs = require('fs');
let html = fs.readFileSync('index.html', 'utf8');

// 1. Footer layout fix
// Replace min-h-screen with min-h-screen
// Replace footer classes
html = html.replace(
  /<footer class="[^"]*">/,
  '<footer class="h-auto lg:h-12 bg-news-dark text-gray-500 text-[10px] flex flex-col lg:flex-row items-center px-6 justify-between shrink-0 border-t border-black py-4 lg:py-0 gap-4 lg:gap-0 w-full mt-auto relative">'
);

// Remove the global Video and Audio sections from the sidebar
// Find main-sidebar and keep only the Ad
html = html.replace(
  /<aside id="main-sidebar".*?<\/aside>/s,
  `<aside id="main-sidebar" class="w-full lg:w-1/3 flex flex-col gap-4 pb-10">
    <a href="https://example.com" target="_blank" id="dynamic-ad-link" class="bg-gray-200 border-dashed border-2 border-gray-300 flex flex-col items-center justify-center p-2 relative flex-shrink-0 cursor-pointer hover:bg-gray-300 transition-colors h-32 w-full block">
      <span class="absolute top-1 left-1 text-[8px] font-bold text-gray-400 uppercase tracking-widest z-10">Advertisement</span>
      <div class="text-center w-full h-full flex flex-col items-center justify-center">
        <img id="dynamic-ad-image" src="https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80&w=300&h=250" class="absolute inset-0 w-full h-full object-cover rounded-sm" alt="Ad Background">
        <div class="relative z-20">
          <div id="dynamic-ad-title" class="text-sm font-black text-gray-800 uppercase bg-white/80 px-2 py-1 rounded">Premium Cloud Solutions</div>
          <button class="mt-2 bg-blue-600 hover:bg-blue-700 transition-colors text-white text-[10px] px-3 py-1 font-bold uppercase tracking-wider rounded shadow">Click To Learn More</button>
        </div>
      </div>
    </a>
  </aside>`
);

// 2. Remove Admin Media Config for Audio and Video
// Find admin-media-config and remove the "Update Video Stream" and "Audio Playlist" divs
html = html.replace(/<div class="bg-white p-6 rounded shadow-sm border border-gray-200">\s*<h2 class="font-bold text-lg mb-4 border-b pb-2">Update Video Stream<\/h2>.*?<\/form>\s*<\/div>/s, '');
html = html.replace(/<div class="bg-white p-6 rounded shadow-sm border border-gray-200">\s*<div class="flex items-center justify-between border-b pb-2 mb-4">\s*<h2 class="font-bold text-lg">Audio Playlist<\/h2>.*?<\/form>\s*<\/div>/s, '');


fs.writeFileSync('index.html', html);
console.log('Done replacement part 1');
