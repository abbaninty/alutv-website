const fs = require('fs');

let html = fs.readFileSync('index.html', 'utf8');

const regex = /function getResponsiveVideoPlayer\(url\) \{[\s\S]*?<\/div>\`;\s*\} else \{/g;
html = html.replace(regex, `function getResponsiveVideoPlayer(url) {
if (!url) return '<p style="color:white; padding:10px;">Babu bidiyo da aka ɗora</p>';
const youtubeRegex = /(?:youtube\\.com\\/(?:[^\\/]+\\/.+\\/|(?:v|e(?:mbed)?)\\/|.*[?&]v=)|youtu\\.be\\/)([^"&?\\/\\s]{11})/i;
const match = url.match(youtubeRegex);
if (match && match[1]) {
const videoId = match[1];
return \`
<div style="position:relative; padding-bottom:56.25%; height:0; overflow:hidden; border-radius:8px;">
  \${createYouTubeLazyPlayer('https://www.youtube.com/watch?v=' + videoId, 'w-full h-full absolute inset-0', 'w-full h-full absolute inset-0')}
</div>\`;
} else {`);

fs.writeFileSync('index.html', html);
