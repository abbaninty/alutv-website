const fs = require('fs');
let html = fs.readFileSync('index.html', 'utf8');

// Replace article form
const formStart = html.indexOf('<div id="admin-art-content" contenteditable="true" class="p-3 min-h-[120px] max-h-[300px] overflow-y-auto text-sm focus:outline-none focus:bg-gray-50"></div>');
const formEnd = html.indexOf('</div>\n<div>\n<label class="block text-xs font-bold text-gray-700 mb-1">Article Image (Upload)</label>', formStart);

html = html.replace(
  '<div>\n<label class="block text-xs font-bold text-gray-700 mb-1">Article Image (Upload)</label>\n<input type="file" id="admin-art-image" accept="image/png, image/jpeg, image/*" class="w-full border border-gray-300 rounded p-2 text-sm focus:outline-news-purple bg-white">\n<p class="text-[10px] text-gray-500 mt-1" id="admin-art-image-hint">Required for new posts. Optional when editing.</p>\n</div>',
  `<div>
<label class="block text-xs font-bold text-gray-700 mb-1">Article Image (Upload)</label>
<input type="file" id="admin-art-image" accept="image/png, image/jpeg, image/*" class="w-full border border-gray-300 rounded p-2 text-sm focus:outline-news-purple bg-white">
<p class="text-[10px] text-gray-500 mt-1" id="admin-art-image-hint">Required for new posts. Optional when editing.</p>
</div>
<div>
<label class="block text-xs font-bold text-gray-700 mb-1">Article Video URL (Optional MP4 file link)</label>
<input type="url" id="admin-art-video-url" placeholder="https://.../video.mp4" class="w-full border border-gray-300 rounded p-2 text-sm focus:outline-news-purple bg-white">
</div>
<div>
<label class="block text-xs font-bold text-gray-700 mb-1">Article Audio URL (Optional MP3 file link)</label>
<input type="url" id="admin-art-audio-url" placeholder="https://.../audio.mp3" class="w-full border border-gray-300 rounded p-2 text-sm focus:outline-news-purple bg-white">
</div>`
);

fs.writeFileSync('index.html', html);
console.log('Done replacement part 2');
