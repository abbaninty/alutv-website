const fs = require('fs');
let html = fs.readFileSync('index.html', 'utf8');

// The loop fix
// In openArticle, don't increment views if it's already open, or add an arg.
// It's easier to modify openArticle definition: function openArticle(id, preventViewIncrement = false)
html = html.replace(/function openArticle\(id\) \{/, 'function openArticle(id, preventViewIncrement = false) {');

// In openArticle view increment logic
html = html.replace(/\/\/ Increment views\s*if \(\!article\.views\) \{\s*let numericId = Number\(article\.id\);\s*article\.views = isNaN\(numericId\) \? Math\.floor\(Math\.random\(\) \* 50\) \+ 120 : \(numericId \% 50\) \+ 120;\s*\}\s*article\.views \+\= 1;/g, 
`// Increment views
  if (!preventViewIncrement) {
      if (!article.views) {
          let numericId = Number(article.id);
          article.views = isNaN(numericId) ? Math.floor(Math.random() * 50) + 120 : (numericId % 50) + 120;
      }
      article.views += 1;
  }`);

// In openArticle firebase update
html = html.replace(/\/\/ Try to update firebase\s*if \(typeof db \!\=\= 'undefined' \&\& db\) \{\s*if \(article\.type \=\=\= 'original'\) \{\s*db\.ref\('originals\/' \+ article\.id\)\.update\(\{ views\: article\.views \}\)\.catch\(e \=\> console\.log\(e\)\);\s*\} else \{\s*db\.ref\('articles\/' \+ article\.id\)\.update\(\{ views\: article\.views \}\)\.catch\(e \=\> console\.log\(e\)\);\s*\}\s*\}/g,
`// Try to update firebase
  if (!preventViewIncrement && typeof db !== 'undefined' && db) {
     if (article.type === 'original') {
         db.ref('originals/' + article.id).update({ views: article.views }).catch(e => console.log(e));
     } else {
         db.ref('articles/' + article.id).update({ views: article.views }).catch(e => console.log(e));
     }
  }`);

// In firebase listener for articles, call openArticle with true for preventViewIncrement
html = html.replace(/openArticle\(postId\);/g, 'openArticle(postId, true);');

fs.writeFileSync('index.html', html);
