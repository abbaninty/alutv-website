const fs = require('fs');

let content = fs.readFileSync('index.html', 'utf-8');

// Replace custom CSS definitions
content = content.replace('.bg-news-red { background-color: #BB1919; }', '.bg-news-purple { background-color: #6B46C1; }')
content = content.replace('.text-news-red { color: #BB1919; }', '.text-news-purple { color: #6B46C1; }')

// Replace classes
content = content.replaceAll('bg-news-red', 'bg-news-purple')
content = content.replaceAll('text-news-red', 'text-news-purple')
content = content.replaceAll('focus:outline-news-red', 'focus:outline-purple-600')

// Standard tailwind replacements
content = content.replaceAll('bg-red-800', 'bg-purple-800')
content = content.replaceAll('text-red-600', 'text-purple-600')
content = content.replaceAll('text-red-500', 'text-purple-500')
content = content.replaceAll('bg-red-500', 'bg-purple-500')
content = content.replaceAll('bg-red-600', 'bg-purple-600')
content = content.replaceAll('hover:bg-red-700', 'hover:bg-purple-700')
content = content.replaceAll('hover:bg-red-800', 'hover:bg-purple-800')
content = content.replaceAll('bg-red-900/30', 'bg-purple-900/30')
content = content.replaceAll('text-red-400', 'text-purple-400')
content = content.replaceAll('hover:text-red-900', 'hover:text-purple-900')
content = content.replaceAll('border-red-600', 'border-purple-600')
content = content.replaceAll('group-hover:text-red-700', 'group-hover:text-purple-700')
content = content.replaceAll('hover:text-red-800', 'hover:text-purple-800')

fs.writeFileSync('index.html', content);
